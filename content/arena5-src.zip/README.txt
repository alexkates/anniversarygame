If you want to run this code locally, you will also need the canvask3d library code from here:
http://www.kevs3d.co.uk/dev/canvask3d/canvask3d-src.zip