DEBUG =
{
   INVINCIBLE: false,
   COLLISIONRADIUS: false,
   DISABLEGLOWEFFECT: false,
   FPS: false
};
